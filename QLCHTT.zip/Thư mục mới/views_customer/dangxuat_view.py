import customtkinter as ctk


class LogoutPage(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, fg_color="#f1f5f9")
        self.controller = controller

        # Card xác nhận
        card = ctk.CTkFrame(self, fg_color="white", corner_radius=20, width=400, height=300)
        card.place(relx=0.5, rely=0.5, anchor="center")
        card.pack_propagate(False)

        ctk.CTkLabel(card, text="🚪", font=("Arial", 60)).pack(pady=20)
        ctk.CTkLabel(card, text="ĐĂNG XUẤT", font=("Arial", 20, "bold")).pack(pady=5)
        ctk.CTkLabel(card, text="Bạn có chắc chắn muốn thoát không?", font=("Arial", 14)).pack(pady=10)

        # Nút xác nhận thoát
        ctk.CTkButton(card, text="Xác nhận thoát", fg_color="#ef4444", hover_color="#dc2626",
                      height=40, command=self.controller.logout_process).pack(pady=10, padx=50, fill="x")

        # Nút hủy (quay lại shop)
        ctk.CTkButton(card, text="Hủy", fg_color="#94a3b8", hover_color="#64748b",
                      height=40, command=lambda: self.controller.show_frame("ShopPage")).pack(pady=5, padx=50, fill="x")