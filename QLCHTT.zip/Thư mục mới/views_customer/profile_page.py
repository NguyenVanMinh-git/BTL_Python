import customtkinter as ctk


class ProfilePage(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, fg_color="transparent")

        # Thân trang
        card = ctk.CTkFrame(self, fg_color="#ffffff", corner_radius=24, width=550, height=650, border_width=1,
                            border_color="#f1f5f9")
        card.place(relx=0.5, rely=0.5, anchor="center")
        card.pack_propagate(False)

        # Header Card (Màu Gradient giả)
        header_blue = ctk.CTkFrame(card, fg_color="#2563eb", height=120, corner_radius=0)
        header_blue.pack(fill="x", side="top")

        # Ảnh đại diện (Bỏ border_width và border_color để tránh lỗi hệ thống)
        # Sửa lại: Xóa border_width và border_color của CTkLabel
        avatar_label = ctk.CTkLabel(card, text="👤", font=("Arial", 60),
                                    fg_color="#f8fafc", width=110, height=110,
                                    corner_radius=55)
        avatar_label.place(relx=0.5, rely=0.18, anchor="center")

        # Nội dung dưới
        content_frame = ctk.CTkFrame(card, fg_color="transparent")
        content_frame.pack(fill="both", expand=True, pady=(100, 20))

        ctk.CTkLabel(content_frame, text="Tài khoản cá nhân", font=("Inter", 24, "bold"), text_color="#1e293b").pack()
        ctk.CTkLabel(content_frame, text="Cập nhật thông tin để nhận ưu đãi mới nhất", font=("Inter", 13),
                     text_color="#94a3b8").pack(pady=(0, 25))

        # Ô nhập liệu hiện đại
        self.create_field(content_frame, "HỌ VÀ TÊN", "Minh Trí")
        self.create_field(content_frame, "EMAIL / SỐ ĐIỆN THOẠI", "customer@example.com")
        self.create_field(content_frame, "ĐỊA CHỈ MẶC ĐỊNH", "Hà Nội, Việt Nam")

        # Nút Lưu tinh tế
        save_btn = ctk.CTkButton(content_frame, text="Lưu thay đổi", font=("Inter", 15, "bold"),
                                 fg_color="#2563eb", hover_color="#1d4ed8",
                                 height=50, corner_radius=14)
        save_btn.pack(pady=30, padx=60, fill="x")

    def create_field(self, parent, label, value):
        f = ctk.CTkFrame(parent, fg_color="transparent")
        f.pack(fill="x", padx=60, pady=10)
        ctk.CTkLabel(f, text=label, font=("Inter", 11, "bold"), text_color="#64748b").pack(anchor="w")
        e = ctk.CTkEntry(f, height=45, corner_radius=12, fg_color="#f8fafc", border_color="#e2e8f0", border_width=1)
        e.insert(0, value)
        e.pack(fill="x", pady=5)