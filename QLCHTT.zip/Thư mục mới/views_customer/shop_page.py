import customtkinter as ctk


class ShopPage(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, fg_color="transparent")
        self.controller = controller

        # --- HEADER ---
        header = ctk.CTkFrame(self, fg_color="white", height=70, corner_radius=15)
        header.pack(fill="x", pady=(0, 20))

        ctk.CTkLabel(header, text="🛍️ DANH SÁCH SẢN PHẨM",
                     font=("Inter", 20, "bold"), text_color="#1e293b").pack(side="left", padx=25)

        # --- KHU VỰC HIỂN THỊ SẢN PHẨM (Scrollable) ---
        self.scroll_canvas = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.scroll_canvas.pack(fill="both", expand=True)

        # Cấu hình lưới: 3 cột sản phẩm
        self.scroll_canvas.columnconfigure((0, 1, 2), weight=1, pad=20)

    def load_products(self, products):
        """
        Hàm này nhận dữ liệu từ Controller (liên kết từ database của Admin)
        products: danh sách các tuple (id, name, price, size, stock, ...)
        """
        # Xóa các sản phẩm cũ trước khi load mới
        for widget in self.scroll_canvas.winfo_children():
            widget.destroy()

        if not products:
            ctk.CTkLabel(self.scroll_canvas, text="Chưa có sản phẩm nào được bày bán.",
                         font=("Inter", 14)).grid(row=0, column=0, columnspan=3, pady=50)
            return

        for index, prod in enumerate(products):
            p_id, p_name, p_price, p_size, p_stock = prod[0], prod[1], prod[2], prod[3], prod[4]

            # Tạo Card cho từng sản phẩm
            card = ctk.CTkFrame(self.scroll_canvas, fg_color="white", corner_radius=20, height=320,
                                border_width=1, border_color="#f1f5f9")
            card.grid(row=index // 3, column=index % 3, padx=10, pady=10, sticky="nsew")
            card.grid_propagate(False)

            # Giả lập ảnh sản phẩm (Icon)
            img_box = ctk.CTkFrame(card, fg_color="#f8fafc", height=160, corner_radius=15)
            img_box.pack(fill="x", padx=10, pady=10)
            ctk.CTkLabel(img_box, text="👕", font=("Inter", 60)).place(relx=0.5, rely=0.5, anchor="center")

            # Thông tin sản phẩm
            info_frame = ctk.CTkFrame(card, fg_color="transparent")
            info_frame.pack(fill="both", expand=True, padx=15)

            ctk.CTkLabel(info_frame, text=p_name, font=("Inter", 16, "bold"), text_color="#1e293b").pack(anchor="w")

            price_stock_frame = ctk.CTkFrame(info_frame, fg_color="transparent")
            price_stock_frame.pack(fill="x", pady=5)

            ctk.CTkLabel(price_stock_frame, text=f"{p_price:,.0f}đ", font=("Inter", 15, "bold"),
                         text_color="#2563eb").pack(side="left")
            ctk.CTkLabel(price_stock_frame, text=f"Kho: {p_stock}", font=("Inter", 12), text_color="#64748b").pack(
                side="right")

            # Nút Thêm vào giỏ hàng
            btn_add = ctk.CTkButton(card, text="Thêm vào giỏ", font=("Inter", 13, "bold"),
                                    fg_color="#2563eb", hover_color="#1d4ed8",
                                    height=40, corner_radius=12,
                                    command=lambda p=prod: self.controller.add_to_cart(p))
            btn_add.pack(fill="x", padx=15, pady=(0, 15))