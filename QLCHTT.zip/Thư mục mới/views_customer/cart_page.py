import customtkinter as ctk

class CartPage(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, fg_color="#f1f5f9")
        self.controller = controller
        ctk.CTkLabel(self, text="GIỎ HÀNG", font=("Arial", 22, "bold")).pack(pady=20)
        self.scroll = ctk.CTkScrollableFrame(self, fg_color="white", width=700, height=450)
        self.scroll.pack(pady=10, padx=30)

    def refresh_cart(self, items):
        for widget in self.scroll.winfo_children(): widget.destroy()
        if not items:
            ctk.CTkLabel(self.scroll, text="Giỏ hàng trống").pack(pady=20)
            return
        for item in items:
            row = ctk.CTkFrame(self.scroll, fg_color="#f8fafc")
            row.pack(fill="x", pady=5)
            ctk.CTkLabel(row, text=item[1]).pack(side="left", padx=20)
            ctk.CTkLabel(row, text=f"{item[2]:,.0f}đ").pack(side="right", padx=20)