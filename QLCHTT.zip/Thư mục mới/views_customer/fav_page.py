import customtkinter as ctk

class FavPage(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, fg_color="#f1f5f9")
        self.controller = controller
        ctk.CTkLabel(self, text="DANH SÁCH YÊU THÍCH", font=("Arial", 22, "bold")).pack(pady=50)
        ctk.CTkLabel(self, text="Chưa có sản phẩm nào được yêu thích.").pack()