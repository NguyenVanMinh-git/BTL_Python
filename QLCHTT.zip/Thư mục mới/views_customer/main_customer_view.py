import customtkinter as ctk


class MainCustomerView(ctk.CTk):
    def __init__(self, controller):
        super().__init__()
        self.controller = controller
        self.title("MINH TRÍ STORE - PREMIUM")
        self.geometry("1280x850")
        self.configure(fg_color="#f8fafc")  # Nền Slate nhạt cực sang

        # Sidebar với viền mảnh
        self.sidebar = ctk.CTkFrame(self, width=280, corner_radius=0, fg_color="#ffffff", border_width=1,
                                    border_color="#f1f5f9")
        self.sidebar.pack(side="left", fill="y")

        # Header Logo
        logo_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        logo_frame.pack(pady=(50, 60))
        ctk.CTkLabel(logo_frame, text="M", font=("Inter", 32, "bold"), text_color="#ffffff",
                     fg_color="#2563eb", width=50, height=50, corner_radius=12).pack(side="left", padx=10)
        ctk.CTkLabel(logo_frame, text="MINH TRÍ", font=("Inter", 20, "bold"), text_color="#1e293b").pack(side="left")

        # Menu điều hướng
        self.nav_btns = {}
        menu_items = [
            ("🛍️", "Cửa hàng", "ShopPage"),
            ("🛒", "Giỏ hàng", "CartPage"),
            ("❤️", "Yêu thích", "FavPage"),
            ("👤", "Cá nhân", "ProfilePage")
        ]

        for icon, text, page in menu_items:
            btn_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
            btn_frame.pack(fill="x", padx=25, pady=4)

            btn = ctk.CTkButton(
                btn_frame, text=f"  {icon}  {text}",
                font=("Inter", 14, "bold"),
                anchor="w", height=48, corner_radius=12,
                fg_color="transparent", text_color="#64748b",
                hover_color="#f8fafc",
                command=lambda p=page: self.controller.show_frame(p)
            )
            btn.pack(fill="x")
            self.nav_btns[page] = btn

        # Footer Đăng xuất
        logout_btn = ctk.CTkButton(
            self.sidebar, text="🚪  Đăng xuất",
            font=("Inter", 14, "bold"),
            fg_color="transparent", text_color="#94a3b8",
            hover_color="#fff1f2", height=48, corner_radius=12,
            command=lambda: self.controller.show_frame("LogoutPage")
        )
        logout_btn.pack(side="bottom", fill="x", padx=25, pady=40)

        # Container nội dung với hiệu ứng đổ bóng giả
        self.container = ctk.CTkFrame(self, fg_color="transparent")
        self.container.pack(side="right", fill="both", expand=True, padx=40, pady=40)