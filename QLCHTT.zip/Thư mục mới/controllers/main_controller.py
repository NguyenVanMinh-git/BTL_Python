from models.database import Database
from views.product_page import ProductEntryWindow

class MainController:
    def __init__(self):
        self.db = Database()

    def open_add_product(self, parent_view):
        # Mở popup và truyền hàm 'add_to_db' làm callback
        ProductEntryWindow(parent_view, self.add_to_db)

    def add_to_db(self, data):
        # data nhận từ popup: (name, price, img)
        self.db.add_product(data[0], data[1], 10, "Áo", data[2])
        # Sau đó gọi lệnh refresh giao diện ở đây